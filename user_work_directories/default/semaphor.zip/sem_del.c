#include <stdio.h>
#include <sys/ipc.h>
#include <sys/sem.h>
int main(int argc, char * argv[])
{//программа удаляющая семафор по файловому ключу
	key_t key;
	key = ftok(argv[1], 's');
	int sem_id = semget(key, 0, 0);

	printf("sem key %d \n", sem_id);
	
	if(semctl(sem_id, 0, IPC_RMID) == -1)
		printf("error del semaphore\n");
	else
		printf("sem del success!\n");
	

	return 0;
}
