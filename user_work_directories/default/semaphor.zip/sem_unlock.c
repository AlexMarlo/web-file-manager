#include <stdio.h>
#include <sys/ipc.h>
#include <sys/sem.h>

int main(int argc, char * argv[])
{//Программа разблокировки занятого семафора
	key_t key = ftok(argv[1], 's');
	int sem_id = sem_get_or_create(key);
	
	if(sem_id == -1)
	{
		printf("Semaphore semget error\n");
		return 0;
	}

	struct sembuf sem_buf;
	sem_buf.sem_op = 1;
	sem_buf.sem_num = 0;
	sem_buf.sem_flg = 0;

	if(semop(sem_id, &sem_buf, 1) < 0)
		printf("sem not unlocked!\n");
	else
		printf("sem  unlocked success!\n");

	return 0;
}

int sem_get_or_create(key_t key)
{
	return semget(key, 1, 0);
}
