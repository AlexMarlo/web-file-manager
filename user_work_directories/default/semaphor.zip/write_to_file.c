#include <stdio.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/stat.h>
 
int main(int argc, char *argv[])
{
//проверка аргументов введенных из терминала при запуске программы
//1 параметр файл для записи
//2 параметр строка для добавления в файл
	if(argc < 3)
	{//если параметров меньше 2 говорим что мало параметров
		printf("too few params\n");
		return 0;
	}
	else if(argc > 3)
	{//если параметров больше 2 говорим что слишком много параметров
		printf("too many params\n");
		return 0;
	}
//проверяем что введенный из терминала файл существует
//если его нет создаем пустой файл с таким именем
	if(file_exists(argv[1]) < 0)
	{
		if(create_file(argv[1]) < 0)
		{
			printf("Error while create not exist file!\n");
			return 0;
		}
	}
//Генерируем уникальный ключ для файла
//для использования при работе с семафором	
	key_t key;
	if((key = ftok(argv[1], 's')) < 0)
	{
		printf("Can\'t generate key!\n");
		return 0;
	}
//получаем идентификатор семафора
//если он есть то просто получаем его идентификатор
//если нет то содаеться новый
	int sem_id = sem_get_or_create(key);

//если при получении идентификатора семафора произошла ошибка выводим соответствующее сообщение и выходим из программы	
	if(sem_id < 0)
	{
		printf("Semaphore semget error!\n");
		return 0;
	}

	printf("check sem id %d \n", sem_id);
//если семафор занят то ждем его освобождения
//после чего программа продолжаеться и семафор занимаеться
	sem_wait(sem_id);
	printf("lock sem\n");

//
	if(write_str_to_file(argv[1], argv[2]) < 0)
	{//если ошибка записи в файл выводим соответствующее сообщени
	//обязательно освобаждаем семафор для других процессов
	//и затем выходим из программы
		printf("File writing error!");
		sem_unlock(sem_id);
		return 0;
	}
//освобождам семафор для другого процесса
	sem_unlock(sem_id);
	printf("sem unlocked\n");
//звершаем работу программы
	return 0;
}

//Проверяем существование файла
int file_exists(char * file_path)
{
	FILE *file;
	file = fopen(file_path, "r");
	if(!file)
		return -1;
	fclose(file);
	return 0;
}

//создаем пустой файл
int create_file(char * file_path)
{
	FILE *file;
	file = fopen(file_path, "a+");
	if(!file)
		return -1;
	fclose(file);
	return 0;
}

//открываем файл для добавления и пишем в конец строку
int write_str_to_file(char * file_path, char * str)
{
	FILE *file;
	file = fopen(file_path, "a");
	if(!file)
		return -1;
	
	fputs(str, file);
	fputs("\n", file);
	fclose(file);
	return 0;
}

//Создаем семафор если он не создан
//семафор ищеться по уникальному ключу key привязанному к существующему файлу
//Если семафор уже существует просто получаем его идентификатор sem_id при помощи которого можем с ним работать
int sem_get_or_create(key_t key)
{
	int sem_id;
	sem_id = semget(key, 1, IPC_EXCL|IPC_CREAT|0666);
	if(sem_id < 0)
	{	
		sem_id = semget(key, 1, IPC_CREAT|0666);
		printf("sem_exist sem_id=%d\n", sem_id);
	}
	else
	{
	//так как семафор создаеться по умолчанию со значением 0 те закрытым
	//чтобы нам получить доступ нужно его освободить
		printf("sem created sem_id=%d \n", sem_id);
		sem_unlock(sem_id);
	}

	return sem_id;
}

//ждем если семафор занят
int sem_wait(int sem_id)
{
	struct sembuf sem_buf;
	sem_buf.sem_op = -1;
	sem_buf.sem_num = 0;
	sem_buf.sem_flg = 0;

	return semop(sem_id, &sem_buf, 1);
}

//освободить семафор
int sem_unlock(int sem_id)
{
	struct sembuf sem_buf;
	sem_buf.sem_op = 1;
	sem_buf.sem_num = 0;
	sem_buf.sem_flg = 0;

	return semop(sem_id, &sem_buf, 1);
}
//установить значение семафора
int sem_get_val(int sem_id)
{
	return semctl(sem_id, 0, GETVAL);
}

