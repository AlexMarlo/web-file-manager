#include <stdio.h>
#include <sys/ipc.h>
#include <sys/sem.h>
int main(int argc, char * argv[])
{//программа блокировки семафора
	key_t key;
	key = ftok(argv[1], 's');
	int sem_id = semget(key, 1, 0);
	
	struct sembuf sem_buf;
	sem_buf.sem_op = -1;
	sem_buf.sem_num = 0;
	sem_buf.sem_flg = IPC_NOWAIT;
	if(semop(sem_id, &sem_buf, 1) < 0)
		printf("sem not locked!\n");
	else	
		printf("sem locked success!\n");
	
	printf("sem key %d \n", sem_id);
	

	return 0;
}
